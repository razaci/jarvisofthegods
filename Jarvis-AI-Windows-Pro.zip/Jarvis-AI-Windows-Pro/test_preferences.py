import os,sys,tempfile,unittest
from pathlib import Path
from unittest.mock import patch,Mock
sys.path.insert(0,str(Path(__file__).parent/'GUI'))
import preferences as p
from speech import Speech
class PreferencesTest(unittest.TestCase):
    def test_chat_roundtrip_and_limit(self):
        with tempfile.TemporaryDirectory() as folder,patch.object(p,'DATA',Path(folder)):
            p.save_chat([{'role':'You','text':str(n)} for n in range(250)])
            self.assertEqual(len(p.load_chat()),200)
            p.save_chat([]);self.assertEqual(p.load_chat(),[])
    def test_settings_apply(self):
        import commands
        with tempfile.TemporaryDirectory() as folder,patch.object(p,'ROOT',Path(folder)),patch.object(p,'DATA',Path(folder)),patch.dict(os.environ):
            root=Path(folder);(root/'.env.example').write_text('OPENAI_API_KEY=\n')
            p.save_settings({'OPENAI_API_KEY':'fake-key','OPENAI_MODEL':'test-model','AI_PROVIDER':'openai'},{'speech_rate':200})
            self.assertEqual(commands.OPENAI_API_KEY,'fake-key')
            self.assertEqual(p.load_preferences()['speech_rate'],200)
            self.assertIn('fake-key',(root/'.env').read_text())
    def test_speech_stop(self):
        speech=Speech();proc=Mock();proc.poll.return_value=None;speech.process=proc
        speech.stop();proc.terminate.assert_called_once();self.assertTrue(proc._jarvis_cancelled)
if __name__=='__main__':unittest.main()
