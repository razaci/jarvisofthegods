import sys
import unittest
from pathlib import Path
from unittest.mock import patch,Mock
sys.path.insert(0,str(Path(__file__).parent/'GUI'))
import commands as c
class OpenAITest(unittest.TestCase):
    def setUp(self):
        c._history.clear()
        self.key=patch.object(c,'OPENAI_API_KEY','test-key');self.key.start()
        self.provider=patch.object(c,'AI_PROVIDER','auto');self.provider.start()
    def tearDown(self):self.key.stop();self.provider.stop();c._history.clear()
    def response(self,text='Hello'):
        response=Mock(ok=True)
        response.json.return_value={'output':[{'type':'message','content':[{'type':'output_text','text':text}]}]}
        return response
    def test_request_and_memory(self):
        with patch.object(c.requests,'post',return_value=self.response()) as post:
            self.assertEqual(c.handle('hello'),'Hello')
            self.assertEqual(post.call_args.args[0],'https://api.openai.com/v1/responses')
            self.assertFalse(post.call_args.kwargs['json']['store'])
            self.assertEqual(post.call_args.kwargs['headers']['Authorization'],'Bearer test-key')
            c.handle('remember that')
            self.assertEqual(len(post.call_args.kwargs['json']['input']),3)
    def test_key_missing(self):
        with patch.object(c,'AI_PROVIDER','openai'),patch.object(c,'OPENAI_API_KEY',''):
            self.assertIn('missing',c.handle('hello'))
    def test_bad_key(self):
        response=Mock(ok=False,status_code=401)
        with patch.object(c.requests,'post',return_value=response):
            with self.assertRaisesRegex(ValueError,'401'):c.handle('hello')
            self.assertEqual(c._history,[])
    def test_timeout(self):
        with patch.object(c.requests,'post',side_effect=c.requests.Timeout):
            with self.assertRaisesRegex(ValueError,'timed out'):c.handle('hello')
    def test_bounded_and_clear(self):
        with patch.object(c.requests,'post',return_value=self.response()):
            for n in range(10):c.handle('question '+str(n))
            self.assertEqual(len(c._history),12)
            c.handle('clear chat');self.assertEqual(c._history,[])
    def test_local_command_no_api(self):
        with patch.object(c.requests,'post') as post:
            c.handle('time');post.assert_not_called()
    def test_empty_output(self):
        response=Mock(ok=True);response.json.return_value={'output':[]}
        with patch.object(c.requests,'post',return_value=response):
            self.assertIn('no text',c.handle('hello'));self.assertEqual(c._history,[])
    def test_provider_status(self):self.assertIn('OpenAI',c.handle('ai status'))
if __name__=='__main__':unittest.main()
