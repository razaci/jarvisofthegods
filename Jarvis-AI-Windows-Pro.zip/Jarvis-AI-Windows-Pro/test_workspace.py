import sys,os,tempfile,unittest,zipfile
from pathlib import Path
from unittest.mock import patch,Mock
sys.path.insert(0,str(Path(__file__).parent/'GUI'))
import workspace as w
import vision
import commands
class WorkspaceTest(unittest.TestCase):
    def test_backup_excludes_secrets(self):
        with tempfile.TemporaryDirectory() as folder:
            root=Path(folder);game=root/'game';game.mkdir();data=root/'data';data.mkdir()
            (game/'index.html').write_text('<h1>Game</h1>');(game/'.env').write_text('SECRET');(game/'.env.local').write_text('SECRET')
            (game/'node_modules').mkdir();(game/'node_modules'/'unused.txt').write_text('unused')
            with patch.object(w,'DATA',data):archive,count=w.backup_project(game)
            self.assertEqual(count,1)
            with zipfile.ZipFile(archive) as z:self.assertEqual(z.namelist(),['game/index.html'])
    def test_routine_validates_before_launch(self):
        with patch.object(commands,'handle') as handle:
            with self.assertRaises(ValueError):w.run_routine('command: open notepad\ncommand: delete files')
            handle.assert_not_called()
    def test_routine_notes_and_commands(self):
        with patch.object(commands,'handle',return_value='Opened') as handle:
            text=w.run_routine('command: open notepad\nnote: Check mail')
            self.assertIn('Checklist',text);handle.assert_called_once_with('open notepad')
    def test_routine_rejects_script_url(self):
        with self.assertRaises(ValueError):w.run_routine('url: javascript:alert(1)')
    def test_storage_and_export(self):
        with tempfile.TemporaryDirectory() as folder,patch.object(w,'DATA',Path(folder)):
            w.save('songs',{'song':'lyrics'});self.assertEqual(w.load('songs',{}),{'song':'lyrics'})
            exported=w.export_text('song','lyrics');self.assertEqual(exported.read_text(),'lyrics')
    def test_vision_payload(self):
        from PIL import Image
        with tempfile.TemporaryDirectory() as folder:
            image=Path(folder)/'image.png';Image.new('RGB',(32,32)).save(image)
            response=Mock(ok=True);response.json.return_value={'output':[{'type':'message','content':[{'type':'output_text','text':'Explanation'}]}]}
            with patch.object(commands,'OPENAI_API_KEY','test'),patch.object(vision.requests,'post',return_value=response) as post:
                self.assertEqual(vision.analyze_image(image,'Explain'),'Explanation')
                content=post.call_args.kwargs['json']['input'][0]['content']
                self.assertEqual(content[1]['type'],'input_image');self.assertTrue(content[1]['image_url'].startswith('data:image/jpeg;base64,'))
    def test_vision_missing_key(self):
        with patch.object(commands,'OPENAI_API_KEY',''):
            with self.assertRaisesRegex(ValueError,'OpenAI key'):vision.analyze_image('image.png','Explain')
if __name__=='__main__':unittest.main()
