import os,sys,tempfile,unittest,types
from pathlib import Path
from unittest.mock import patch,Mock
sys.path.insert(0,str(Path(__file__).parent/'GUI'))
import files_engine as f
import local_ai as local
import jobs
from screen_guide import parse_step,execute_step
class ProTest(unittest.TestCase):
    def test_save_undo_restores_bytes(self):
        with tempfile.TemporaryDirectory() as folder:
            root=Path(folder);data=root/'data';data.mkdir();code=root/'index.html';original=b'\xef\xbb\xbf<html>\r\n<body>old</body>\r\n</html>';code.write_bytes(original)
            with patch.object(f,'DATA',data):
                _,checksum=f.read_code(code);updated=f.save_code(code,'<html><body>new</body></html>',checksum)
                text,checksum=f.undo_code(code,updated);self.assertEqual(code.read_bytes(),original)
    def test_outside_change_blocked(self):
        with tempfile.TemporaryDirectory() as folder:
            code=Path(folder)/'code.py';code.write_text('x=1');_,checksum=f.read_code(code);code.write_text('x=2')
            with self.assertRaisesRegex(ValueError,'outside'):f.save_code(code,'x=3',checksum)
    def test_syntax(self):
        self.assertIn('passed',f.check_code('a.py','x=1'))
        with self.assertRaises(SyntaxError):f.check_code('a.py','x=')
    def test_document_and_folder(self):
        with tempfile.TemporaryDirectory() as folder:
            root=Path(folder);(root/'notes.md').write_text('ship\nmission objective')
            (root/'.env.txt').write_text('SECRET mission')
            self.assertIn('mission',f.read_document(root/'notes.md'))
            result=f.search_folder(root,'mission');self.assertIn('2: mission',result);self.assertNotIn('SECRET',result)
    def test_html_hidden_script(self):
        with tempfile.TemporaryDirectory() as folder:
            code=Path(folder)/'a.html';code.write_text('<body>Hello<script>secret()</script></body>')
            self.assertIn('Hello',f.read_document(code));self.assertNotIn('secret',f.read_document(code))
    def test_local_endpoint(self):
        with patch.dict(os.environ,{'LOCAL_AI_URL':'https://remote.example.com'}):
            with self.assertRaises(ValueError):local.endpoint()
    def test_local_chat(self):
        response=Mock();response.json.return_value={'message':{'content':'local reply'}}
        with patch.dict(os.environ,{'LOCAL_AI_URL':'http://localhost:11434','LOCAL_AI_BACKEND':'ollama','LOCAL_AI_MODEL':'test'}),patch.object(local.requests,'post',return_value=response) as post:
            self.assertEqual(local.chat('hello'),'local reply');self.assertFalse(post.call_args.kwargs['json']['stream'])
    def test_lm_chat(self):
        response=Mock();response.json.return_value={'choices':[{'message':{'content':'LM reply'}}]}
        with patch.dict(os.environ,{'LOCAL_AI_URL':'http://localhost:1234','LOCAL_AI_BACKEND':'lmstudio','LOCAL_AI_MODEL':'test'}),patch.object(local.requests,'post',return_value=response) as post:
            self.assertEqual(local.chat('hello'),'LM reply');self.assertTrue(post.call_args.args[0].endswith('/v1/chat/completions'))
    def test_jobs_sequential(self):
        with patch.object(jobs,'load',return_value=[]),patch.object(jobs,'save'),patch.object(jobs,'perform_step',return_value='done') as perform:
            queue=jobs.JobQueue();queue.add('test','note: one\nnote: two');queue.run()
            self.assertEqual(queue.items[0]['state'],'done');self.assertEqual(perform.call_count,2)
    def test_jobs_bad_path_rejected(self):
        with self.assertRaises(ValueError):jobs.validate_steps('launch: Z:/missing/game.html')
    def test_job_failure_stops(self):
        with patch.object(jobs,'load',return_value=[]),patch.object(jobs,'save'),patch.object(jobs,'perform_step',side_effect=ValueError('failed')) as perform:
            queue=jobs.JobQueue();queue.add('test','note: one\nnote: two');queue.run();self.assertEqual(queue.items[0]['state'],'failed');self.assertEqual(perform.call_count,1)
    def test_guide_one_approved_step(self):
        pg=Mock();pg.size.return_value=(1000,800)
        with patch.dict(sys.modules,{'pyautogui':pg}),patch('screen_guide.time.sleep'):
            execute_step('click: 200,300');pg.click.assert_called_once_with(200,300);pg.write.assert_not_called()
    def test_guide_invalid(self):
        with self.assertRaises(ValueError):parse_step('shell: delete')
        with self.assertRaises(ValueError):parse_step('wait: 100')
if __name__=='__main__':unittest.main()
