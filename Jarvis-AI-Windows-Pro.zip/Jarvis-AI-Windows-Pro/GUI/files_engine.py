import ast
import difflib
import hashlib
import json
import os
import re
import uuid
from pathlib import Path
from html.parser import HTMLParser
from preferences import DATA,atomic_json
TEXT_EXT={'.txt','.md','.html','.htm','.csv','.tsv','.json','.py','.js','.css','.xml','.log'}
EDIT_EXT=TEXT_EXT-{'.log'}
def digest(text):return hashlib.sha256(text.encode('utf-8')).hexdigest()
def read_code(path):
    path=Path(path).expanduser().resolve()
    if path.suffix.lower() not in EDIT_EXT or path.stat().st_size>3*1024*1024:raise ValueError('Choose a supported text/code file smaller than 3 MB.')
    text=path.read_bytes().decode('utf-8-sig');return text,digest(text)
def save_code(path,text,expected):
    path=Path(path).expanduser().resolve();old,current=read_code(path)
    if current!=expected:raise ValueError('File changed outside Jarvis. Reload before saving.')
    if old==text:return current
    folder=DATA/'revisions'/hashlib.sha256(str(path).encode()).hexdigest();folder.mkdir(parents=True,exist_ok=True)
    manifest=folder/'history.json'
    history=json.loads(manifest.read_text()) if manifest.exists() else []
    snapshot=folder/(uuid.uuid4().hex+'.txt');snapshot.write_bytes(path.read_bytes())
    updated=digest(text)
    history.append({'snapshot':snapshot.name,'before':current,'after':updated})
    # Keep the journal durable before replacing the reviewed file.
    atomic_json(manifest,history)
    temp=path.with_name(path.name+'.jarvis-tmp');temp.write_text(text,encoding='utf-8');temp.replace(path)
    return updated

def undo_code(path,expected):
    path=Path(path).expanduser().resolve();_,current=read_code(path)
    if current!=expected:raise ValueError('File changed outside Jarvis. Reload before undo.')
    folder=DATA/'revisions'/hashlib.sha256(str(path).encode()).hexdigest();manifest=folder/'history.json'
    history=json.loads(manifest.read_text()) if manifest.exists() else []
    if not history:raise ValueError('No Jarvis revision to undo.')
    latest=history[-1]
    if latest['after']!=current:raise ValueError('Current file does not match the saved revision. Reload and review it.')
    original_bytes=(folder/latest['snapshot']).read_bytes();old=original_bytes.decode('utf-8-sig')
    temp=path.with_name(path.name+'.jarvis-tmp');temp.write_bytes(original_bytes);temp.replace(path)
    atomic_json(manifest,history[:-1]);return old,digest(old)

def diff(before,after):return ''.join(difflib.unified_diff(before.splitlines(True),after.splitlines(True),fromfile='current',tofile='proposed')) or 'No changes.'
def check_code(path,text):
    if Path(path).suffix.lower()=='.py':ast.parse(text);return 'Python syntax passed. Code was not executed.'
    if Path(path).suffix.lower()=='.json':json.loads(text);return 'JSON syntax passed.'
    if Path(path).suffix.lower() in ('.html','.htm'):
        parser=HTMLParser();parser.feed(text)
        warnings=[]
        if '<html' not in text.lower():warnings.append('No html element')
        if '<body' not in text.lower():warnings.append('No body element')
        return 'HTML parsed. '+('; '.join(warnings) if warnings else 'Open in your browser to check rendering and JavaScript.')
    return 'File is editable; this workspace has no compiler for that language.'
class VisibleHTML(HTMLParser):
    def __init__(self):super().__init__();self.parts=[];self.skip=0
    def handle_starttag(self,tag,attrs):
        if tag in ('script','style'):self.skip+=1
    def handle_endtag(self,tag):
        if tag in ('script','style'):self.skip=max(0,self.skip-1)
    def handle_data(self,data):
        if not self.skip:self.parts.append(data)

def read_document(path):
    path=Path(path).expanduser().resolve()
    if path.stat().st_size>20*1024*1024:raise ValueError('Document is larger than 20 MB.')
    ext=path.suffix.lower()
    if ext in TEXT_EXT:
        text=path.read_text(encoding='utf-8',errors='replace')
        if ext in ('.html','.htm'):
            parser=VisibleHTML();parser.feed(text);text='\n'.join(parser.parts)
    elif ext=='.pdf':
        from pypdf import PdfReader
        reader=PdfReader(path);text='\n'.join((page.extract_text() or '') for page in reader.pages[:100])
    elif ext=='.docx':
        from docx import Document
        doc=Document(path);text='\n'.join([para.text for para in doc.paragraphs]+[' | '.join(cell.text for cell in row.cells) for table in doc.tables for row in table.rows])
    else:raise ValueError('Supported: text/code, CSV, HTML, PDF and DOCX.')
    if not text.strip():raise ValueError('No readable text found. Scanned PDFs need OCR, which is not included.')
    return text[:120000]

def search_folder(folder,query):
    folder=Path(folder).expanduser().resolve()
    if not folder.is_dir() or not query.strip():raise ValueError('Choose a folder and enter search words.')
    results=[];scanned=0;truncated=False
    for root,dirs,files in os.walk(folder,followlinks=False):
        dirs[:]=[d for d in dirs if d not in ('.git','.venv','node_modules','__pycache__') and not (Path(root)/d).is_symlink()]
        for name in files:
            path=Path(root)/name
            if path.suffix.lower() not in TEXT_EXT|{'.pdf','.docx'} or name.startswith('.env') or path.is_symlink():continue
            scanned+=1
            if scanned>200:truncated=True;break
            try:text=read_document(path)
            except Exception:continue
            matches=[]
            for number,line in enumerate(text.splitlines(),1):
                if query.casefold() in line.casefold():matches.append(f'{number}: {line[:500]}')
                if len(matches)>=5:break
            if matches or query.casefold() in name.casefold():results.append(str(path)+'\n'+'\n'.join(matches))
            if len(results)>=30:truncated=True;break
        if truncated:break
    return f'Scanned {min(scanned,200)} documents'+(' (limit reached)' if truncated else '')+'\n\n'+('\n\n'.join(results) or 'No matches found.')
