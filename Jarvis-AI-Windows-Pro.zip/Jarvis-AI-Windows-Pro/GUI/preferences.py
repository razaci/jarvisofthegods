import json
import os
from pathlib import Path
from dotenv import set_key
from constants import ROOT
DATA = Path(os.getenv('LOCALAPPDATA', str(Path.home()/'.local/share')))/'Jarvis-AI'
DATA.mkdir(parents=True,exist_ok=True)
DEFAULTS={'voice_id':'','speech_rate':185,'microphone':None,'speak_responses':False}
def load_preferences():
    try:return {**DEFAULTS,**json.loads((DATA/'preferences.json').read_text())}
    except (OSError,ValueError,TypeError):return DEFAULTS.copy()
def atomic_json(path,data):
    temp=path.with_suffix('.tmp');temp.write_text(json.dumps(data,ensure_ascii=False),encoding='utf-8');temp.replace(path)
def save_settings(values,preferences):
    env=ROOT/'.env'
    if not env.exists():env.write_bytes((ROOT/'.env.example').read_bytes())
    for key,value in values.items():
        set_key(str(env),key,str(value));os.environ[key]=str(value)
    atomic_json(DATA/'preferences.json',preferences)
    # Existing command module imports configuration values; update them live.
    import commands, constants
    for key in ('OPENAI_API_KEY','OPENAI_MODEL','GEMINI_API_KEY','GEMINI_MODEL','AI_PROVIDER','USER'):
        env_key='USER_NAME' if key=='USER' else key
        value=os.getenv(env_key,getattr(constants,key,''))
        setattr(constants,key,value);setattr(commands,key,value)
    commands._history.clear()
def load_chat():
    try:
        data=json.loads((DATA/'conversation.json').read_text(encoding='utf-8'))
        return [m for m in data[-200:] if isinstance(m,dict) and m.get('role') in ('You','Jarvis','System') and isinstance(m.get('text'),str)]
    except (OSError,ValueError,TypeError):return []
def save_chat(messages):atomic_json(DATA/'conversation.json',messages[-200:])
