import os
import subprocess
import webbrowser
from datetime import datetime
from urllib.parse import quote_plus
import requests
import threading
_api_lock=threading.RLock()
from personality import instructions
from constants import USER, GEMINI_API_KEY, GEMINI_MODEL, OPENAI_API_KEY, OPENAI_MODEL, AI_PROVIDER
from utils import find_my_ip, youtube, search_on_google, search_on_wikipedia, get_news, weather_forecast

HELP = "Commands: time; date; open notepad; open command prompt; open camera; open discord; open gta; ip address; youtube <search>; search on google <search>; search on wikipedia <topic>; weather <city>; tell me news; movie <title>. Other text goes to the configured OpenAI or Gemini chat. Type ai status or clear chat. Email uses the Email button."
def handle(query):
    query = query.strip(); low = query.lower()
    if not query: return 'Type a command or click Listen.'
    if low in ('help','commands'): return HELP
    if low == 'clear chat':
        from local_ai import _history as local_history
        local_history.clear()
        _history.clear(); return 'Chat memory cleared.'
    if low == 'ai status':
        provider = selected_provider()
        if provider == 'local': return 'Local AI / '+os.getenv('LOCAL_AI_MODEL','no model selected')
        if provider == 'openai': return f'OpenAI / {OPENAI_MODEL}. API key: ' + ('configured' if OPENAI_API_KEY else 'missing')
        if provider == 'gemini': return f'Gemini / {GEMINI_MODEL}. API key: ' + ('configured' if GEMINI_API_KEY else 'missing')
        return 'No AI key configured. Open Configure-AI.cmd to edit .env; then restart.'
    if low in ('time','what time is it'): return datetime.now().strftime('It is %I:%M %p.')
    if low in ('date','what is the date'): return datetime.now().strftime('%A, %B %d, %Y')
    if 'how are you' in low: return f'I am ready to help, {USER}.'
    apps={'open notepad':['notepad.exe'], 'open command prompt':['cmd.exe']}
    if low in apps:
        if os.name != 'nt': return 'This command requires Windows.'
        subprocess.Popen(apps[low]); return 'Opened ' + low[5:] + '.'
    if low == 'open camera':
        if os.name != 'nt': return 'This command requires Windows.'
        os.startfile('microsoft.windows.camera:'); return 'Opened Camera.'
    if low in ('open discord','open gta'):
        key = 'DISCORD_PATH' if low.endswith('discord') else 'GTA_PATH'
        path = os.getenv(key,'')
        if not path or not os.path.isfile(path): return f'Set {key} in .env to the executable on your PC.'
        os.startfile(path); return 'Opened ' + low[5:] + '.'
    if 'ip address' in low: return 'Your public IP address is ' + find_my_ip()
    for prefix, action in [('search on google',search_on_google),('open google',search_on_google),('youtube',youtube),('open youtube',youtube),('search on wikipedia',search_on_wikipedia),('wikipedia',search_on_wikipedia)]:
        if low == prefix or low.startswith(prefix+' '):
            term=query[len(prefix):].strip()
            if not term: return f'Please type {prefix} followed by a search topic.'
            result=action(term); return result or 'Opened search results for ' + term + '.'
    if low == 'weather' or low.startswith('weather '):
        city=query[7:].strip()
        if not city: return 'Type weather followed by a city, for example weather Spokane.'
        desc,temp,feels=weather_forecast(city); return f'{city}: {desc}, {temp}; feels like {feels}.'
    if low in ('tell me news','give me news','news'): return '\n'.join(get_news()) or 'No headlines returned.'
    if low == 'movie' or low.startswith('movie '):
        title=query[6:].strip()
        if not title: return 'Type movie followed by a title.'
        import imdb
        matches=imdb.IMDb().search_movie(title)
        return '\n'.join(f"{m.get('title','Unknown')} ({m.get('year','year unknown')})" for m in matches[:5]) or 'No movies found.'
    if low in ('send an email','send email'): return 'Use the Email button to enter and review the recipient, subject, and message.'
    if low == 'subscribe':
        webbrowser.open('https://www.youtube.com/'); return 'Opened YouTube. Choose a channel there.'
    provider = selected_provider()
    if provider == 'local':
        from local_ai import chat
        with _api_lock:return chat(query)
    if provider == 'openai':
        with _api_lock:return openai_chat(query)
    if provider not in ('gemini', 'none'): raise ValueError('AI_PROVIDER must be auto, openai, gemini, or local in .env.')
    if not GEMINI_API_KEY: return 'AI is not configured. Local commands work now; open Configure-AI.cmd and add OPENAI_API_KEY or GEMINI_API_KEY to .env. Then restart. Type help for commands.'
    response=requests.post('https://generativelanguage.googleapis.com/v1beta/models/'+GEMINI_MODEL+':generateContent', headers={'x-goog-api-key':GEMINI_API_KEY}, json={'contents':[{'parts':[{'text':instructions()+'\nUser: '+query}]}]}, timeout=45)
    if not response.ok: raise ValueError(f'Gemini returned HTTP {response.status_code}. Check the API key and GEMINI_MODEL in .env.')
    candidates=response.json().get('candidates',[])
    if not candidates: return 'Gemini returned no response.'
    return ''.join(part.get('text','') for part in candidates[0].get('content',{}).get('parts',[])) or 'Gemini returned no text.'


_history = []
def selected_provider():
    if AI_PROVIDER != 'auto': return AI_PROVIDER
    if OPENAI_API_KEY: return 'openai'
    if GEMINI_API_KEY: return 'gemini'
    return 'none'

def openai_chat(query):
    if not OPENAI_API_KEY:
        return 'OpenAI API key is missing. Open Configure-AI.cmd, set OPENAI_API_KEY in .env, and restart Jarvis.'
    messages = _history[-12:] + [{'role':'user','content':query}]
    try:
        response = requests.post(
            'https://api.openai.com/v1/responses',
            headers={'Authorization':'Bearer '+OPENAI_API_KEY, 'Content-Type':'application/json'},
            json={'model':OPENAI_MODEL,'input':messages,'store':False,
                  'instructions':instructions(),
                  'max_output_tokens':int(os.getenv('MAX_OUTPUT_TOKENS','6000'))},
            timeout=(10,90))
    except requests.Timeout:
        raise ValueError('OpenAI timed out. Please try again.') from None
    except requests.RequestException:
        raise ValueError('Cannot reach OpenAI. Check your internet connection.') from None
    if not response.ok:
        hints={401:'Check OPENAI_API_KEY in .env.',403:'Your API project may not have permission.',
               404:'Check OPENAI_MODEL and your model access.',429:'Check API credits and rate limits; try again later.'}
        raise ValueError(f'OpenAI returned HTTP {response.status_code}. ' + hints.get(response.status_code,'Please try again or check your API settings.'))
    try: data=response.json()
    except ValueError: raise ValueError('OpenAI returned an unreadable response.') from None
    if data.get('status')=='incomplete':raise ValueError('AI output reached its limit. Request a smaller change or increase MAX_OUTPUT_TOKENS in .env.')
    parts=[]
    for item in data.get('output',[]):
        if item.get('type') != 'message': continue
        for part in item.get('content',[]):
            if part.get('type') == 'output_text': parts.append(part.get('text',''))
            elif part.get('type') == 'refusal': parts.append(part.get('refusal',''))
    text='\n'.join(parts).strip()
    if not text: return 'OpenAI returned no text. Try again or check the selected model.'
    _history.extend([{'role':'user','content':query},{'role':'assistant','content':text}])
    # Bounded, session-only memory. No API key or conversations written to disk.
    del _history[:-12]
    while sum(len(m['content']) for m in _history) > 24000 and len(_history)>2:
        del _history[:2]
    return text
