import threading
import time
import uuid
from pathlib import Path
from workspace import load,save,backup_project,open_local,run_routine,export_text
from files_engine import read_document

def validate_steps(text):
    result=[]
    for line in text.splitlines():
        if not line.strip():continue
        kind,sep,value=line.partition(':');kind=kind.strip().lower();value=value.strip()
        if not sep or kind not in ('backup','launch','open','read','ask','note','routine'):raise ValueError('Steps: backup:, launch:, open:, read:, ask:, note:, routine:')
        if not value:raise ValueError('Each step needs a value.')
        if kind in ('backup','launch','open','read'):
            path=Path(value).expanduser()
            if not path.exists():raise ValueError('Missing path: '+value)
            if kind=='backup' and not path.is_dir():raise ValueError('Backup needs a folder.')
            if kind=='launch' and path.suffix.lower() not in ('.html','.htm'):raise ValueError('Launch needs an HTML game file.')
            if kind=='read' and not path.is_file():raise ValueError('Read needs a document file.')
        if kind=='routine' and value not in load('routines',{}):raise ValueError('Unknown saved routine: '+value)
        result.append((kind,value))
    if not result:raise ValueError('Add at least one step.')
    return result

def perform_step(kind,value):
    if kind=='backup':
        path,count=backup_project(value);return f'Backup: {path} ({count} files)'
    if kind in ('open','launch'):open_local(value);return 'Opened '+value
    if kind=='read':return value+'\n'+read_document(value)[:24000]
    if kind=='ask':
        from commands import handle
        return handle(value)
    if kind=='note':return 'Note exported: '+str(export_text('job-note',value))
    return run_routine(load('routines',{})[value])

class JobQueue:
    def __init__(self):
        self.lock=threading.RLock();self.items=load('jobs',[]);self.thread=None;self.paused=False
        for job in self.items:
            if job['state'] in ('running','queued'):job['state']='interrupted'
        self.persist()
    def persist(self):save('jobs',self.items[-100:])
    def add(self,name,text):
        steps=validate_steps(text)
        with self.lock:
            job={'id':uuid.uuid4().hex,'name':name or 'New job','steps':steps,'state':'queued','log':[],'cancel':False}
            self.items.append(job);self.persist();return job['id']
    def start(self):
        with self.lock:
            self.paused=False
            if self.thread and self.thread.is_alive():return
            self.thread=threading.Thread(target=self.run,daemon=True);self.thread.start()
    def run(self):
        while True:
            with self.lock:
                if self.paused:return
                job=next((item for item in self.items if item['state']=='queued'),None)
                if not job:return
                job['state']='running';self.persist()
            try:
                for number,(kind,value) in enumerate(job['steps'],1):
                    if job['cancel']:break
                    result=perform_step(kind,value)
                    with self.lock:job['log'].append(f'Step {number}: '+result[:24000]);self.persist()
                job['state']='cancelled' if job['cancel'] else 'done'
            except Exception as exc:job['state']='failed';job['log'].append('Error: '+str(exc))
            with self.lock:self.persist()
    def cancel(self,job_id):
        with self.lock:
            for job in self.items:
                if job['id']==job_id:
                    job['cancel']=True
                    if job['state']!='running':job['state']='cancelled'
            self.persist()
    def snapshot(self):
        with self.lock:return [{'id':j['id'],'name':j['name'],'state':j['state'],'log':list(j['log'])} for j in self.items]
