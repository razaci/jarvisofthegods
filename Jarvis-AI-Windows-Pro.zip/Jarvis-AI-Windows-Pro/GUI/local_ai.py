import os
from urllib.parse import urlparse
import requests
from personality import instructions
_history=[]
def endpoint():
    base=os.getenv('LOCAL_AI_URL','http://localhost:11434').rstrip('/')
    parts=urlparse(base)
    if parts.scheme not in ('http','https') or parts.hostname not in ('localhost','127.0.0.1','::1'):
        raise ValueError('Local AI URL must point to localhost, 127.0.0.1, or ::1.')
    return base

def models():
    kind=os.getenv('LOCAL_AI_BACKEND','ollama')
    url=endpoint()+('/api/tags' if kind=='ollama' else '/v1/models')
    r=requests.get(url,timeout=(3,10));r.raise_for_status();data=r.json()
    return [m['name'] for m in data.get('models',[])] if kind=='ollama' else [m['id'] for m in data.get('data',[])]

def chat(query):
    backend=os.getenv('LOCAL_AI_BACKEND','ollama');model=os.getenv('LOCAL_AI_MODEL','').strip()
    if not model:raise ValueError('Choose an installed model in Local AI settings.')
    messages=[{'role':'system','content':instructions()}]+_history[-8:]+[{'role':'user','content':query}]
    if backend=='ollama':url=endpoint()+'/api/chat';payload={'model':model,'messages':messages,'stream':False}
    elif backend=='lmstudio':url=endpoint()+'/v1/chat/completions';payload={'model':model,'messages':messages,'stream':False,'max_tokens':1800}
    else:raise ValueError('Local backend must be ollama or lmstudio.')
    try:
        r=requests.post(url,json=payload,timeout=(5,180));r.raise_for_status();data=r.json()
    except requests.RequestException:raise ValueError('Local AI unavailable. Start the local server and load the selected model.') from None
    text=data.get('message',{}).get('content','') if backend=='ollama' else data.get('choices',[{}])[0].get('message',{}).get('content','')
    if data.get('done_reason')=='length' or (backend=='lmstudio' and data.get('choices',[{}])[0].get('finish_reason')=='length'):
        raise ValueError('Local output reached its length limit. Ask for a smaller change.')
    if not text:raise ValueError('The local model returned no text.')
    _history.extend([{'role':'user','content':query},{'role':'assistant','content':text}]);del _history[:-8]
    while sum(len(m['content']) for m in _history)>24000 and len(_history)>2:del _history[:2]
    return text
