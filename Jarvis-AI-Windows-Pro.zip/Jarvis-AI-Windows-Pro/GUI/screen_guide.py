import time

def parse_step(line):
    kind,sep,value=line.partition(':');kind=kind.strip().lower();value=value.strip()
    if not sep or kind not in ('click','type','hotkey','wait'):raise ValueError('Steps: click: x,y ; type: text ; hotkey: ctrl,s ; wait: seconds')
    if kind=='click':
        parts=value.split(',')
        if len(parts)!=2:raise ValueError('Click needs x,y coordinates.')
        x,y=map(int,parts)
        if x<0 or y<0:raise ValueError('Coordinates must be positive.')
        return kind,(x,y)
    if kind=='wait':
        seconds=float(value)
        if not 0<=seconds<=10:raise ValueError('Wait must be 0–10 seconds.')
        return kind,seconds
    if kind=='hotkey':
        keys=[key.strip().lower() for key in value.split(',')]
        if not keys or len(keys)>4:raise ValueError('Choose 1–4 keys.')
        return kind,keys
    if not value:raise ValueError('Enter text to type.')
    if not value.isascii():raise ValueError('Typing currently supports ASCII text only.')
    return kind,value

def execute_step(line):
    kind,value=parse_step(line)
    import pyautogui as pg
    pg.FAILSAFE=True
    if kind=='click':
        width,height=pg.size()
        if not 0<=value[0]<width or not 0<=value[1]<height:raise ValueError('Click is outside the primary screen.')
    if kind=='hotkey' and any(key not in pg.KEYBOARD_KEYS for key in value):raise ValueError('Unknown keyboard key.')
    # Give the user time to select the target window after approving one action.
    time.sleep(2)
    if kind=='click':pg.click(*value)
    elif kind=='type':pg.write(value,interval=.03)
    elif kind=='hotkey':pg.hotkey(*value)
    else:time.sleep(value)
    return 'Approved step completed: '+line
