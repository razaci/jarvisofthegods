import json
import subprocess
import sys
import threading
from pathlib import Path
WORKER=Path(__file__).with_name('voice_worker.py')
class Speech:
    def __init__(self):self.process=None;self.lock=threading.Lock()
    def stop(self):
        with self.lock:
            proc=self.process
            if proc and proc.poll() is None:
                proc._jarvis_cancelled=True;proc.terminate()
    def speak(self,text,settings):
        with self.lock:
            if self.process and self.process.poll() is None:
                self.process._jarvis_cancelled=True;self.process.terminate()
            proc=subprocess.Popen([sys.executable,str(WORKER)],stdin=subprocess.PIPE,stdout=subprocess.DEVNULL,stderr=subprocess.PIPE,text=True)
            self.process=proc
        _,error=proc.communicate(json.dumps({'text':str(text),**settings}))
        if proc.returncode != 0 and not getattr(proc,'_jarvis_cancelled',False):raise RuntimeError('Windows speech output failed. Check the selected voice.')
def voices():
    result=subprocess.run([sys.executable,str(WORKER),'--voices'],capture_output=True,text=True,timeout=15)
    if result.returncode:raise RuntimeError('Could not load system voices.')
    return json.loads(result.stdout)
