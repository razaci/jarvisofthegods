from workspace import load
DEFAULT={'name':'Jarvis','greeting':'Ready to help.','style':'Friendly and direct','length':'Medium'}
def settings():return {**DEFAULT,**load('personality',{})}
def instructions():
    p=settings()
    return (f"You are {p['name']}, a helpful desktop chat assistant. Speaking style: {p['style']}. "
            f"Response length: {p['length']}. You can discuss PC tasks but cannot execute actions or inspect the PC. "
            "Only the application built-in commands can perform local actions. Never claim an action was performed unless the application reports it.")
