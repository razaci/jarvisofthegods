import os
import threading
import time
from datetime import datetime
from kivy.clock import Clock
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.button import Button
from kivy.uix.image import Image
from kivy.uix.label import Label
from kivy.uix.textinput import TextInput
from kivy.uix.popup import Popup
from kivy.uix.switch import Switch
from kivy.uix.spinner import Spinner
from kivy.uix.scrollview import ScrollView
from constants import ASSETS, USER
from commands import handle, HELP
from utils import send_email
from preferences import load_preferences, save_settings, load_chat, save_chat, DATA
from speech import Speech, voices

def ui(function):Clock.schedule_once(lambda dt:function())
class Jarvis(BoxLayout):
    def __init__(self, **kwargs):
        super().__init__(orientation='vertical',padding=14,spacing=8,**kwargs)
        self.busy=False;self.preferences=load_preferences();self.messages=load_chat()
        self.speech=Speech();self.release=threading.Event()
        header=BoxLayout(size_hint_y=None,height=90)
        self.animation=Image(source=str(ASSETS/'jarvis.gif'),anim_delay=.05,size_hint_x=.2);header.add_widget(self.animation)
        self.title_label=Label(text='JARVIS AI',font_size=28);header.add_widget(self.title_label);self.add_widget(header)
        self.output=TextInput(readonly=True,font_size=18,background_color=(.06,.09,.13,1),foreground_color=(.88,.95,1,1))
        self.add_widget(self.output)
        self.input=TextInput(hint_text='Type a command or question...',multiline=False,size_hint_y=None,height=46)
        self.input.bind(on_text_validate=self.submit);self.add_widget(self.input)
        row=BoxLayout(size_hint_y=None,height=46,spacing=6)
        self.send=self.button(row,'Send',self.submit)
        self.listen=self.button(row,'Listen once',self.start_recording)
        self.ptt=Button(text='Hold to talk');self.ptt.bind(on_press=self.push_start,on_release=lambda *_:self.release.set());row.add_widget(self.ptt)
        self.button(row,'Stop speaking',self.stop_speaking)
        self.button(row,'Settings',self.ai_setup);self.add_widget(row)
        row=BoxLayout(size_hint_y=None,height=40,spacing=6)
        self.button(row,'Email',self.email_dialog);self.button(row,'Help',lambda *_:self.show(HELP))
        self.button(row,'Export chat',self.export_chat);self.button(row,'Clear chat',self.clear_chat)
        row.add_widget(Label(text='Speak replies'))
        self.voice=Switch(active=self.preferences.get('speak_responses',False));row.add_widget(self.voice);self.add_widget(row)
        self.status=Label(text='Ready',size_hint_y=None,height=34,color=(.3,.85,1,1),halign='center');self.status.bind(size=lambda widget,size:setattr(widget,'text_size',(size[0]-12,None)));self.add_widget(self.status)
        from toolbox import Toolbox
        from personality import settings
        self.tools=Toolbox(self)
        from pro_tools import ProTools
        self.pro=ProTools(self)
        nav=BoxLayout(size_hint_y=None,height=42,spacing=6)
        self.button(nav,'Dashboard',self.tools.dashboard);self.button(nav,'Songs',self.tools.songs);self.button(nav,'Projects',self.tools.projects);self.button(nav,'Advanced',self.pro.dashboard);self.focus_button=self.button(nav,'Focus',self.tools.focus)
        self.add_widget(nav,index=1)
        self.tools.apply_theme();self.title_label.text=settings()['name']
        self.render_chat()
        if not self.messages:self.show(f"Hello {USER}. {settings()['greeting']} Open Dashboard for all tools.")
    def button(self,row,text,callback):
        button=Button(text=text,halign='center');button.bind(size=lambda widget,size:setattr(widget,'text_size',(max(20,size[0]-10),None)));button.bind(on_release=callback);row.add_widget(button);return button
    def append(self,role,text):
        self.messages.append({'role':role,'text':str(text),'time':datetime.now().isoformat(timespec='seconds')})
        self.messages=self.messages[-200:];self.render_chat()
        try:save_chat(self.messages)
        except OSError:self.status.text='Chat displayed; could not save it to disk.'
    def render_chat(self):
        self.output.text='\n\n'.join(m['role']+': '+m['text'] for m in self.messages)
        self.output.cursor=(0,len(self.output._lines)-1)
    def show(self,text):self.append('Jarvis',text)
    def set_busy(self,value,status):
        self.busy=value;self.send.disabled=value;self.listen.disabled=value;self.ptt.disabled=False;self.status.text=status
    def stop_speaking(self,*_):self.speech.stop();self.status.text='Speech stopped' if not self.busy else 'Working; speech stopped'
    def work(self,operation,initial='Working...',speak_result=True,on_result=None):
        if self.busy:return
        self.speech.stop();self.set_busy(True,initial)
        voice=self.voice.active and speak_result
        def worker():
            try:
                result=operation();ui(lambda:self.show(result))
                if on_result:ui(lambda:on_result(result))
                if voice:
                    ui(lambda:setattr(self.status,'text','Speaking...'))
                    self.speech.speak(result,self.preferences.copy())
            except Exception as exc:
                message=self.friendly_error(exc);ui(lambda:self.show(message))
                if on_result:ui(lambda:on_result(message))
            finally:ui(lambda:self.set_busy(False,'Ready'))
        threading.Thread(target=worker,daemon=True).start()
    def friendly_error(self,exc):
        import speech_recognition as sr
        if isinstance(exc,sr.WaitTimeoutError):return 'No speech detected. Try again or type your message.'
        if isinstance(exc,sr.UnknownValueError):return 'I could not understand that recording. Try again or type it.'
        if isinstance(exc,sr.RequestError):return 'Speech recognition could not connect. Check your internet connection.'
        if isinstance(exc,(OSError,AttributeError)) and 'audio' in str(exc).lower():return 'Microphone unavailable. Check Windows microphone permission and the input selected in Settings.'
        return 'Error: '+str(exc)
    def submit(self,*_):
        query=self.input.text.strip()
        if not query or self.busy:return
        self.append('You',query);self.input.text='';self.work(lambda:handle(query))
    def push_start(self,*_):
        if self.busy:return
        self.release.clear();self.record(True)
    def start_recording(self,*_):self.record(False)
    def record(self,held):
        def operation():
            import speech_recognition as sr
            r=sr.Recognizer();r.operation_timeout=20
            ui(lambda:setattr(self.status,'text','Listening — release to send' if held else 'Listening — speak now'))
            with sr.Microphone(device_index=self.preferences.get('microphone')) as source:
                if held:
                    chunks=[];started=time.monotonic()
                    while not self.release.is_set() and time.monotonic()-started<20:
                        chunks.append(source.stream.read(source.CHUNK))
                    if not chunks:raise ValueError('Hold the talk button while you speak, then release it.')
                    audio=sr.AudioData(b''.join(chunks),source.SAMPLE_RATE,source.SAMPLE_WIDTH)
                else:
                    r.adjust_for_ambient_noise(source,duration=.4)
                    audio=r.listen(source,timeout=6,phrase_time_limit=15)
            ui(lambda:setattr(self.status,'text','Recognizing...'))
            query=r.recognize_google(audio,language='en-US')
            ui(lambda:self.append('You',query));ui(lambda:setattr(self.status,'text','Thinking...'))
            return handle(query)
        self.work(operation,'Opening microphone...')
    def clear_chat(self,*_):
        if self.busy:return
        self.speech.stop();self.messages=[]
        handle('clear chat');self.render_chat()
        try:save_chat([]);self.status.text='Chat cleared'
        except OSError:self.status.text='Could not clear saved chat'
    def export_chat(self,*_):
        path=DATA/('chat-'+datetime.now().strftime('%Y%m%d-%H%M%S')+'.txt')
        try:
            path.write_text(self.output.text,encoding='utf-8');self.status.text='Exported: '+str(path)
            if os.name=='nt':os.startfile(str(path))
        except OSError as exc:self.show('Export failed: '+str(exc))
    def ai_setup(self,*_):
        if self.busy:self.status.text='Wait for the current reply before changing settings';return
        outer=BoxLayout(orientation='vertical',spacing=8,padding=8)
        scroll=ScrollView();fields_layout=BoxLayout(orientation='vertical',size_hint_y=None,spacing=6)
        fields_layout.bind(minimum_height=fields_layout.setter('height'));scroll.add_widget(fields_layout);outer.add_widget(scroll)
        fields={}
        keys=[('USER_NAME','Your name','Brian'),('AI_PROVIDER','Provider: auto / openai / gemini / local','auto'),('OPENAI_MODEL','OpenAI model','gpt-4.1-mini'),('OPENAI_API_KEY','OpenAI API key',''),('GEMINI_MODEL','Gemini model','gemini-2.5-flash'),('GEMINI_API_KEY','Gemini API key','')]
        for key,title,default in keys:
            fields_layout.add_widget(Label(text=title,size_hint_y=None,height=26))
            field=TextInput(text=os.getenv(key,default),password=key.endswith('API_KEY'),multiline=False,size_hint_y=None,height=40)
            fields[key]=field;fields_layout.add_widget(field)
        fields_layout.add_widget(Label(text='Voice / speaking speed / microphone',size_hint_y=None,height=30))
        voice=Spinner(text='System default',values=('System default',),size_hint_y=None,height=40);fields_layout.add_widget(voice)
        voice_map={'System default':''}
        rate=TextInput(text=str(self.preferences.get('speech_rate',185)),multiline=False,size_hint_y=None,height=40);fields_layout.add_widget(rate)
        mic=Spinner(text='System default',values=('System default',),size_hint_y=None,height=40);fields_layout.add_widget(mic)
        mic_map={'System default':None}
        info=Label(text='API keys stay in .env on this PC. API billing is separate.\nSaved chat stays on this PC; AI session memory resets on restart.',size_hint_y=None,height=58);fields_layout.add_widget(info)
        actions=BoxLayout(size_hint_y=None,height=44,spacing=6)
        popup=Popup(title='Jarvis Settings',content=outer,size_hint=(.9,.92))
        def save(*_):
            if self.busy:info.text='Finish the current operation before saving.';return
            try:
                values={key:field.text.strip() for key,field in fields.items()}
                if values['AI_PROVIDER'] not in ('auto','openai','gemini','local'):raise ValueError('Provider must be auto, openai, gemini, or local.')
                speed=int(rate.text)
                if not 80<=speed<=350:raise ValueError('Speaking speed must be 80–350.')
                prefs={'voice_id':voice_map.get(voice.text,''),'speech_rate':speed,'microphone':mic_map.get(mic.text),'speak_responses':self.voice.active}
                save_settings(values,prefs);self.preferences=prefs;popup.dismiss();self.status.text='Settings saved and applied'
            except Exception as exc:info.text=str(exc)
        self.button(actions,'Save',save)
        def test_voice(*_):
            if self.busy:return
            settings={'voice_id':voice_map.get(voice.text,''),'speech_rate':int(rate.text) if rate.text.isdigit() else 185}
            def operation():self.speech.speak('Jarvis voice test. Your speech output is working.',settings);return 'Voice test finished.'
            self.work(operation,'Testing voice...',speak_result=False)
        self.button(actions,'Test voice',test_voice)
        def test_mic(*_):
            if self.busy:return
            self.record_test(mic_map.get(mic.text))
        self.button(actions,'Test mic',test_mic);self.button(actions,'Close',popup.dismiss);outer.add_widget(actions)
        def load_devices():
            try:
                items=voices()
                def set_voices():
                    for n,v in enumerate(items):voice_map[f"{n+1}. {v['name']}"]=v['id']
                    voice.values=tuple(voice_map)
                    voice.text=next((k for k,v in voice_map.items() if v==self.preferences.get('voice_id')),'System default')
                ui(set_voices)
            except Exception:pass
            try:
                import speech_recognition as sr
                microphones=sr.Microphone.list_microphone_names()
                def set_mics():
                    for n,name in enumerate(microphones):mic_map[f'{n}: {name}']=n
                    mic.values=tuple(mic_map)
                    mic.text=next((k for k,v in mic_map.items() if v==self.preferences.get('microphone')),'System default')
                ui(set_mics)
            except Exception:ui(lambda:setattr(info,'text','Microphone list unavailable. You can still type. Check Windows audio setup.'))
        threading.Thread(target=load_devices,daemon=True).start();popup.open()
    def record_test(self,index=None):
        def operation():
            import speech_recognition as sr
            r=sr.Recognizer();r.operation_timeout=20
            with sr.Microphone(device_index=index) as source:
                audio=r.listen(source,timeout=6,phrase_time_limit=5)
            return 'Microphone recognized: '+r.recognize_google(audio,language='en-US')
        self.work(operation,'Microphone test — speak now')
    def email_dialog(self,*_):
        layout=BoxLayout(orientation='vertical',padding=12,spacing=8)
        recipient=TextInput(hint_text='Recipient email',multiline=False,size_hint_y=None,height=40)
        subject=TextInput(hint_text='Subject',multiline=False,size_hint_y=None,height=40)
        body=TextInput(hint_text='Message')
        for field in (recipient,subject,body):layout.add_widget(field)
        row=BoxLayout(size_hint_y=None,height=44,spacing=8)
        send=Button(text='Send reviewed email');cancel=Button(text='Cancel');row.add_widget(send);row.add_widget(cancel);layout.add_widget(row)
        popup=Popup(title='Review email before sending',content=layout,size_hint=(.9,.85))
        cancel.bind(on_release=popup.dismiss)
        def send_reviewed(*_):
            if self.busy:return
            to=recipient.text.strip();sub=subject.text;message=body.text
            if '@' not in to or not message.strip():popup.title='Enter a recipient and message';return
            popup.dismiss()
            def action():send_email(to,sub,message);return 'Email sent to '+to+'.'
            self.work(action)
        send.bind(on_release=send_reviewed);popup.open()
