import json
import sys
import pyttsx3
engine=pyttsx3.init()
if len(sys.argv)>1 and sys.argv[1]=='--voices':
    print(json.dumps([{'id':v.id,'name':v.name} for v in engine.getProperty('voices')]))
else:
    data=json.loads(sys.stdin.read())
    if data.get('voice_id'):engine.setProperty('voice',data['voice_id'])
    engine.setProperty('rate',int(data.get('speech_rate',185)))
    engine.setProperty('volume',1.0)
    engine.say(data['text']);engine.runAndWait();engine.stop()
