import os
import time
from pathlib import Path
from datetime import datetime
from kivy.clock import Clock
from kivy.core.window import Window
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.gridlayout import GridLayout
from kivy.uix.button import Button
from kivy.uix.label import Label
from kivy.uix.textinput import TextInput
from kivy.uix.spinner import Spinner
from kivy.uix.scrollview import ScrollView
from kivy.uix.popup import Popup
from kivy.uix.filechooser import FileChooserListView
from kivy.uix.checkbox import CheckBox
from kivy.uix.image import Image
from commands import handle
from workspace import load,save,export_text,open_local,run_routine,backup_project
from personality import settings as personality_settings
from preferences import DATA

THEMES={'Midnight':((.05,.08,.12,1),(.88,.95,1,1),(.2,.75,1,1)),
        'Emerald':((.02,.09,.06,1),(.8,1,.88,1),(.2,.95,.55,1)),
        'Violet':((.09,.04,.14,1),(.95,.88,1,1),(.8,.45,1,1)),
        'Light':((.94,.95,.98,1),(.08,.12,.18,1),(.15,.4,.75,1))}
class Toolbox:
    def __init__(self,owner):
        self.owner=owner;self.compact=False;self.old_size=None
        self.deadline=None;self.paused_seconds=None;self.timer_label=None
        focus=load('focus',{});self.deadline=focus.get('deadline');self.reminder=focus.get('reminder','Focus session complete.')
        Clock.schedule_interval(self.tick,1)
    def field(self,layout,hint,text='',height=42,multiline=False):
        field=TextInput(hint_text=hint,text=text,multiline=multiline,size_hint_y=None,height=height,font_size=16);layout.add_widget(field);return field
    def label(self,layout,text,height=30):
        item=Label(text=text,size_hint_y=None,height=height,halign='center');item.bind(size=lambda widget,size:setattr(widget,'text_size',(max(20,size[0]-10),None)));layout.add_widget(item);return item
    def button(self,layout,title,callback):return self.owner.button(layout,title,callback)
    def row(self,layout,height=42):
        row=BoxLayout(size_hint_y=None,height=height,spacing=6);layout.add_widget(row);return row
    def dialog(self,title):
        layout=BoxLayout(orientation='vertical',padding=12,spacing=8)
        popup=Popup(title=title,content=layout,size_hint=(.93,.92));popup.open();return popup,layout
    def notify(self,message):self.owner.append('System',message)
    def choose(self,title,callback,folder=False,filters=None):
        popup,layout=self.dialog(title)
        chooser=FileChooserListView(path=str(Path.home()),dirselect=folder,filters=filters or [])
        layout.add_widget(chooser)
        hint=self.label(layout,'Choose a folder or file, then click Select.',36)
        row=self.row(layout)
        def selected(*_):
            path=chooser.selection[0] if chooser.selection else (chooser.path if folder else '')
            if not path:hint.text='Choose an item first.';return
            popup.dismiss();callback(path)
        self.button(row,'Select',selected);self.button(row,'Cancel',popup.dismiss)
    def dashboard(self,*_):
        popup,layout=self.dialog('Jarvis Command Dashboard')
        self.label(layout,'Choose a workspace',36)
        grid=GridLayout(cols=load('theme',{}).get('columns',2),spacing=10);layout.add_widget(grid)
        items=[('Floating companion',self.floating),('Custom routines',self.routines),('Songwriting studio',self.songs),('Project workshop',self.projects),('Screen assistant',self.screen),('Personality',self.personality),('Focus & tasks',self.focus),('Search conversations',self.search),('Theme designer',self.theme),('Notes & music',self.notes_music)]
        for name,action in items:
            def open_tool(*args,action=action):popup.dismiss();action()
            self.button(grid,name,open_tool)
        self.button(self.row(layout),'Close',popup.dismiss)
    def floating(self,*_):
        self.compact=not self.compact
        if self.compact:
            self.old_size=Window.size;Window.size=(510,560)
        else:Window.size=self.old_size or (1000,760)
        # Kivy 2.3.0 SDL2 does not expose always_on_top: use the native HWND.
        if os.name=='nt':
            try:
                import ctypes
                from ctypes import wintypes
                user32=ctypes.windll.user32;handles=[]
                callback_type=ctypes.WINFUNCTYPE(wintypes.BOOL,wintypes.HWND,wintypes.LPARAM)
                def find_window(hwnd,param):
                    pid=wintypes.DWORD();user32.GetWindowThreadProcessId(hwnd,ctypes.byref(pid))
                    if pid.value==os.getpid() and user32.IsWindowVisible(hwnd):handles.append(hwnd)
                    return True
                user32.EnumWindows(callback_type(find_window),0)
                if not handles:raise RuntimeError('No desktop window found')
                user32.SetWindowPos.argtypes=[wintypes.HWND,wintypes.HWND,ctypes.c_int,ctypes.c_int,ctypes.c_int,ctypes.c_int,ctypes.c_uint]
                if not user32.SetWindowPos(handles[0],-1 if self.compact else -2,0,0,0,0,0x0003):raise RuntimeError('Could not change window stacking')
            except Exception:
                self.notify('Compact view enabled. Windows could not apply always-on-top; drag the title bar to position it.')
        self.owner.status.text='Companion mode — drag the title bar; Dashboard restores size' if self.compact else 'Full workspace restored'
    def routines(self,*_):
        popup,layout=self.dialog('Custom routines')
        routines=load('routines',{})
        selection=Spinner(text='New routine',values=('New routine',)+tuple(routines),size_hint_y=None,height=40);layout.add_widget(selection)
        name=self.field(layout,'Routine name')
        body=self.field(layout,'One step per line',height=180,multiline=True)
        self.label(layout,'app: C:/path/app.exe    folder: C:/path/folder\nurl: https://...    command: open notepad    note: Your checklist',60)
        state=TextInput(text='Save a routine, then Run it.',readonly=True);layout.add_widget(state)
        def select(*_):
            if selection.text in routines:name.text=selection.text;body.text=routines[selection.text]
            else:name.text='';body.text=''
        selection.bind(text=select)
        def store(*_):
            if not name.text.strip():state.text='Enter a name.';return
            routines[name.text.strip()]=body.text;save('routines',routines);selection.values=('New routine',)+tuple(routines);state.text='Saved.'
        def remove(*_):
            routines.pop(name.text.strip(),None);save('routines',routines);selection.values=('New routine',)+tuple(routines);selection.text='New routine';state.text='Deleted.'
        row=self.row(layout);self.button(row,'Save',store);self.button(row,'Run reviewed steps',lambda *_:self.run_steps(body.text,state))
        self.button(row,'Delete',remove);self.button(row,'Close',popup.dismiss)
    def songs(self,*_):
        popup,layout=self.dialog('Songwriting studio')
        songs=load('songs',{})
        select=Spinner(text='New song',values=('New song',)+tuple(songs),size_hint_y=None,height=38);layout.add_widget(select)
        title=self.field(layout,'Song title');brief=self.field(layout,'Theme, genre, emotion, language')
        editor=TextInput(hint_text='Lyrics, verses, hooks, and ideas...',font_size=18);layout.add_widget(editor)
        def change(*_):
            if select.text in songs:title.text=select.text;editor.text=songs[select.text]
            else:title.text='';editor.text=''
        select.bind(text=change)
        def store(*_):
            if not title.text.strip():self.notify('Give the song a title first.');return
            songs[title.text.strip()]=editor.text;save('songs',songs);select.values=('New song',)+tuple(songs);self.owner.status.text='Song saved'
        def generate(kind):
            query=f'Write original song lyrics. {kind}. Title: {title.text}. Brief: {brief.text}. Existing lyrics: {editor.text[:12000]}'
            self.owner.work(lambda:handle(query),on_result=lambda result:setattr(editor,'text',(editor.text+'\n\n'+result).strip()))
        row=self.row(layout);self.button(row,'Save',store);self.button(row,'Draft song',lambda *_:generate('Produce a complete song with labeled verses and repeated chorus'))
        self.button(row,'Build hook',lambda *_:generate('Provide three short strong chorus options'))
        self.button(row,'Export',lambda *_:self.notify('Exported: '+str(export_text('song',title.text+'\n\n'+editor.text))))
        row=self.row(layout)
        def delete(*_):
            songs.pop(title.text.strip(),None);save('songs',songs);select.values=('New song',)+tuple(songs);select.text='New song'
        self.button(row,'Delete song',delete);self.button(row,'Close',popup.dismiss)
    def projects(self,*_):
        popup,layout=self.dialog('Project workshop')
        projects=load('projects',{})
        selected=Spinner(text='Choose project',values=tuple(projects),size_hint_y=None,height=40);layout.add_widget(selected)
        title=self.field(layout,'Project name');path=self.field(layout,'Project folder')
        entry=self.field(layout,'HTML entry file relative to folder','index.html')
        status=TextInput(readonly=True,text='Register your HTML game folder to launch it or create a backup ZIP.');layout.add_widget(status)
        def choose(*_):
            if selected.text in projects:
                project=projects[selected.text];title.text=selected.text;path.text=project['folder'];entry.text=project.get('entry','index.html')
        selected.bind(text=choose)
        def store(*_):
            if not title.text.strip() or not Path(path.text).expanduser().is_dir():status.text='Enter a name and existing folder.';return
            projects[title.text.strip()]={'folder':path.text,'entry':entry.text};save('projects',projects);selected.values=tuple(projects);status.text='Project registered.'
        def launch(*_):
            folder=Path(path.text).expanduser().resolve();html=(folder/entry.text).resolve()
            if not html.is_relative_to(folder) or html.suffix.lower() not in ('.html','.htm'):status.text='Choose an HTML entry inside your folder.';return
            try:open_local(html);status.text='Opened '+str(html)
            except Exception as exc:status.text=str(exc)
        def backup(*_):
            folder=path.text
            def action():
                archive,count=backup_project(folder);return f'Backup saved: {archive} ({count} files).'
            self.owner.work(action,on_result=lambda text:setattr(status,'text',text))
        row=self.row(layout);self.button(row,'Choose folder',lambda *_:self.choose('Choose game folder',lambda value:setattr(path,'text',value),folder=True))
        self.button(row,'Register',store);self.button(row,'Launch HTML',launch);self.button(row,'Backup ZIP',backup)
        row=self.row(layout)
        def remove(*_):projects.pop(title.text.strip(),None);save('projects',projects);selected.values=tuple(projects);status.text='Removed from Jarvis; project files kept.'
        self.button(row,'Remove entry',remove);self.button(row,'Close',popup.dismiss)
    def screen(self,*_):
        popup,layout=self.dialog('Screen assistant — choose your screenshot')
        path=self.field(layout,'PNG or JPEG screenshot path')
        preview=Image();layout.add_widget(preview)
        question=self.field(layout,'What should Jarvis explain?','Explain this screenshot and help me troubleshoot it.')
        self.label(layout,'Analyze sends only your chosen image to OpenAI. Review it first.',38)
        answer=TextInput(readonly=True,size_hint_y=.45);layout.add_widget(answer)
        def chosen(value):path.text=value;preview.source=value
        def analyze(*_):
            from vision import analyze_image
            selected=path.text;prompt=question.text
            self.owner.work(lambda:analyze_image(selected,prompt),initial='Analyzing chosen screenshot...',on_result=lambda text:setattr(answer,'text',text))
        row=self.row(layout);self.button(row,'Choose screenshot',lambda *_:self.choose('Choose screenshot',chosen,filters=['*.png','*.jpg','*.jpeg']))
        self.button(row,'Analyze chosen image',analyze);self.button(row,'Close',popup.dismiss)
    def personality(self,*_):
        popup,layout=self.dialog('Voice personality')
        values=personality_settings()
        name=self.field(layout,'Assistant name',values['name'])
        greeting=self.field(layout,'Greeting',values['greeting'])
        style=self.field(layout,'Speaking style',values['style'])
        length=Spinner(text=values['length'],values=('Short','Medium','Detailed'),size_hint_y=None,height=44);layout.add_widget(length)
        self.label(layout,'Name and greeting update the interface; style/length guide AI replies.',45)
        def store(*_):
            save('personality',{'name':name.text.strip() or 'Jarvis','greeting':greeting.text,'style':style.text,'length':length.text})
            self.owner.title_label.text=name.text.strip() or 'Jarvis';self.notify(greeting.text);popup.dismiss()
        self.button(self.row(layout),'Save personality',store);self.button(self.row(layout),'Close',popup.dismiss)
    def focus(self,*_):
        popup,layout=self.dialog('Focus timer & daily tasks')
        self.timer_label=self.label(layout,'No running timer',48)
        minutes=self.field(layout,'Minutes','25');reminder=self.field(layout,'Spoken reminder','Focus session complete. Take a short break.')
        row=self.row(layout)
        def start(*_):
            try:
                duration=float(minutes.text)*60
                if not 1<=duration<=86400:raise ValueError()
                self.deadline=time.time()+duration;self.reminder=reminder.text;self.paused_seconds=None;save('focus',{'deadline':self.deadline,'reminder':self.reminder});self.tick(0)
            except ValueError:self.timer_label.text='Enter a duration between 1 second and 24 hours.'
        def pause(*_):
            if self.deadline:self.paused_seconds=max(0,self.deadline-time.time());self.deadline=None
            elif self.paused_seconds:self.deadline=time.time()+self.paused_seconds;self.paused_seconds=None
            save('focus',{'deadline':self.deadline,'reminder':self.reminder});self.tick(0)
        def cancel(*_):self.deadline=None;self.paused_seconds=None;save('focus',{});self.tick(0)
        self.button(row,'Start',start);self.button(row,'Pause / resume',pause);self.button(row,'Cancel timer',cancel)
        tasks=load('tasks',[]);entry=self.field(layout,'New daily task')
        scroll=ScrollView();listbox=BoxLayout(orientation='vertical',size_hint_y=None,spacing=4);listbox.bind(minimum_height=listbox.setter('height'));scroll.add_widget(listbox);layout.add_widget(scroll)
        def render():
            listbox.clear_widgets()
            for task in tasks:
                row=self.row(listbox,40);check=CheckBox(active=task.get('done',False),size_hint_x=.15);row.add_widget(check);row.add_widget(Label(text=task['text']))
                def changed(_,value,task=task):task['done']=value;save('tasks',tasks)
                check.bind(active=changed)
                def remove(*_,task=task):tasks.remove(task);save('tasks',tasks);render()
                self.button(row,'Remove',remove)
        def add(*_):
            if entry.text.strip():tasks.append({'text':entry.text.strip(),'done':False});save('tasks',tasks);entry.text='';render()
        render();row=self.row(layout);self.button(row,'Add task',add);self.button(row,'Close',popup.dismiss);self.tick(0)
    def tick(self,dt):
        if self.deadline:
            seconds=max(0,int(self.deadline-time.time()));text=f'Focus: {seconds//60:02d}:{seconds%60:02d}'
            if time.time()>=self.deadline:
                self.deadline=None;save('focus',{});self.owner.status.text='Focus complete'
                # Spoken reminder is local and does not invoke any AI API.
                message=self.reminder
                Clock.schedule_once(lambda dt:self.deliver_reminder(message),0)
        elif self.paused_seconds is not None:text=f'Paused: {int(self.paused_seconds)//60:02d}:{int(self.paused_seconds)%60:02d}'
        else:text='No running timer'
        if self.timer_label:self.timer_label.text=text
        if hasattr(self.owner,'focus_button'):self.owner.focus_button.text=text if self.deadline or self.paused_seconds is not None else 'Focus'
    def run_steps(self,text,state):self.owner.work(lambda:run_routine(text),on_result=lambda result:setattr(state,'text',result))
    def deliver_reminder(self,message):
        if self.owner.busy:
            Clock.schedule_once(lambda dt:self.deliver_reminder(message),1);return
        def action():
            self.owner.speech.speak(message,self.owner.preferences.copy());return message
        self.owner.work(action,initial='Focus complete',speak_result=False)
    def search(self,*_):
        popup,layout=self.dialog('Search saved conversation')
        query=self.field(layout,'Search words')
        results=TextInput(readonly=True);layout.add_widget(results)
        def find(*_):
            term=query.text.strip().casefold()
            matches=[m for m in self.owner.messages if term and term in m['text'].casefold()]
            results.text='\n\n'.join(m.get('time','')+' '+m['role']+': '+m['text'] for m in matches) or 'No matching messages.'
        query.bind(on_text_validate=find);self.button(self.row(layout),'Search',find);self.button(self.row(layout),'Close',popup.dismiss)
    def apply_theme(self):
        values=load('theme',{'name':'Midnight','font':18,'animation':True})
        background,foreground,accent=THEMES.get(values.get('name'),THEMES['Midnight'])
        self.owner.output.background_color=background;self.owner.output.foreground_color=foreground
        self.owner.output.font_size=values.get('font',18);self.owner.input.font_size=values.get('font',18)
        self.owner.title_label.color=accent;self.owner.status.color=accent
        self.owner.animation.anim_delay=.05 if values.get('animation',True) else -1
        if not values.get('animation',True):self.owner.animation.anim_reset(True)
    def theme(self,*_):
        popup,layout=self.dialog('Theme designer')
        values=load('theme',{'name':'Midnight','font':18,'animation':True})
        selected=Spinner(text=values['name'],values=tuple(THEMES),size_hint_y=None,height=44);layout.add_widget(selected)
        font=self.field(layout,'Text size (14–30)',str(values['font']))
        animation=Spinner(text='Animated' if values.get('animation',True) else 'Still',values=('Animated','Still'),size_hint_y=None,height=44);layout.add_widget(animation)
        columns=Spinner(text=str(values.get('columns',2)),values=('1','2'),size_hint_y=None,height=44);layout.add_widget(columns)
        state=self.label(layout,'Palette, text size, animation, dashboard columns',45)
        def apply(*_):
            try:
                size=int(font.text)
                if not 14<=size<=30:raise ValueError()
                save('theme',{'name':selected.text,'font':size,'animation':animation.text=='Animated','columns':int(columns.text)});self.apply_theme();state.text='Theme saved and applied.'
            except ValueError:state.text='Enter a font size between 14 and 30.'
        self.button(self.row(layout),'Apply theme',apply);self.button(self.row(layout),'Close',popup.dismiss)
    def notes_music(self,*_):
        popup,layout=self.dialog('Notes, apps & music')
        notes=load('notes',{})
        selection=Spinner(text='New note',values=('New note',)+tuple(notes),size_hint_y=None,height=38);layout.add_widget(selection)
        title=self.field(layout,'Note title');body=TextInput(hint_text='Notes...');layout.add_widget(body)
        def change(*_):
            title.text='' if selection.text=='New note' else selection.text;body.text=notes.get(selection.text,'')
        selection.bind(text=change)
        def store(*_):
            if not title.text.strip():return
            notes[title.text.strip()]=body.text;save('notes',notes);selection.values=('New note',)+tuple(notes);self.owner.status.text='Note saved'
        row=self.row(layout);self.button(row,'Save note',store)
        self.button(row,'Export note',lambda *_:self.notify('Exported: '+str(export_text('note',title.text+'\n'+body.text))))
        def delete(*_):notes.pop(title.text.strip(),None);save('notes',notes);selection.values=('New note',)+tuple(notes);selection.text='New note'
        self.button(row,'Delete note',delete)
        row=self.row(layout)
        for label,command in [('Notepad','open notepad'),('Camera','open camera')]:self.button(row,label,lambda *_,command=command:self.owner.work(lambda:handle(command)))
        self.button(row,'Play music file',lambda *_:self.choose('Choose music file',lambda path:self.owner.work(lambda:(open_local(path) or 'Opened music in your Windows player.')),filters=['*.mp3','*.wav','*.flac','*.m4a']))
        self.button(row,'Close',popup.dismiss)
