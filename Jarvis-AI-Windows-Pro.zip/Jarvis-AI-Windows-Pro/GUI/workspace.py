import json
import os
import subprocess
import webbrowser
import zipfile
from datetime import datetime
from pathlib import Path
from urllib.parse import urlparse
from preferences import DATA, atomic_json

def load(name,default):
    try:return json.loads((DATA/(name+'.json')).read_text(encoding='utf-8'))
    except (OSError,ValueError):return default

def save(name,value):atomic_json(DATA/(name+'.json'),value)

def export_text(prefix,text):
    folder=DATA/'exports';folder.mkdir(exist_ok=True)
    path=folder/(prefix+'-'+datetime.now().strftime('%Y%m%d-%H%M%S-%f')+'.txt')
    path.write_text(text,encoding='utf-8');return path

def open_local(path):
    path=Path(path).expanduser()
    if not path.exists():raise ValueError('That file or folder does not exist.')
    if os.name=='nt':os.startfile(str(path))
    else:raise ValueError('Opening local files is available on Windows.')

def run_routine(text):
    # Deliberately finite actions: no shell evaluation or arbitrary code.
    from commands import handle
    lines=[line.strip() for line in text.splitlines() if line.strip()]
    if not lines:raise ValueError('Add at least one step.')
    parsed=[]
    for line in lines:
        kind,sep,value=line.partition(':');kind=kind.strip().lower();value=value.strip()
        if not sep or kind not in ('app','folder','url','command','note'):raise ValueError('Each step starts app:, folder:, url:, command:, or note:')
        if kind in ('app','folder') and not Path(value).expanduser().exists():raise ValueError('Missing path: '+value)
        if kind=='url' and urlparse(value).scheme not in ('http','https'):raise ValueError('URLs must start https:// or http://')
        if kind=='command' and value.lower() not in ('time','date','open notepad','open command prompt','open camera','open discord','open gta'):raise ValueError('Routine commands: time, date, or the built-in open app commands.')
        parsed.append((kind,value))
    results=[]
    for kind,value in parsed:
        if kind in ('app','folder'):open_local(value);results.append('Opened '+value)
        elif kind=='url':webbrowser.open(value);results.append('Opened '+value)
        elif kind=='command':results.append(handle(value))
        else:results.append('Checklist: '+value)
    return '\n'.join(results)

EXCLUDED={'.git','.venv','venv','node_modules','__pycache__','.env'}
def backup_project(folder):
    folder=Path(folder).expanduser().resolve()
    if not folder.is_dir():raise ValueError('Choose a project folder.')
    target=DATA/'backups';target.mkdir(exist_ok=True)
    if folder==DATA.resolve() or DATA.resolve().is_relative_to(folder):raise ValueError('Choose your game project folder, outside Jarvis data.')
    archive=target/(folder.name+'-'+datetime.now().strftime('%Y%m%d-%H%M%S-%f')+'.zip')
    count=0
    try:
        with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as output:
            for current,dirs,files in os.walk(folder,followlinks=False):
                dirs[:]=[d for d in dirs if d not in EXCLUDED and not (Path(current)/d).is_symlink()]
                for name in files:
                    source=Path(current)/name
                    if name in EXCLUDED or name.startswith('.env.') or source.is_symlink():continue
                    output.write(source,folder.name+'/'+source.relative_to(folder).as_posix());count+=1
    except Exception:
        archive.unlink(missing_ok=True);raise
    return archive,count
