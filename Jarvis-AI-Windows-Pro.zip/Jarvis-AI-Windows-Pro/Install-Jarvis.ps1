$ErrorActionPreference = 'Stop'
$source = $PSScriptRoot
$destination = Join-Path $env:LOCALAPPDATA 'Programs\Jarvis-AI-Pro'
if ([IO.Path]::GetFullPath($source) -eq [IO.Path]::GetFullPath($destination)) {
    Write-Host 'Already installed. Run Setup-Windows.cmd here.'
    exit 0
}
New-Item -ItemType Directory -Force -Path $destination | Out-Null
Get-ChildItem -LiteralPath $source -Force | Where-Object { $_.Name -notin @('.venv','__pycache__','.env') } | ForEach-Object {
    Copy-Item -LiteralPath $_.FullName -Destination $destination -Recurse -Force
}
$installedEnv = Join-Path $destination '.env'
if (!(Test-Path $installedEnv) -and (Test-Path (Join-Path $source '.env'))) {
    Copy-Item -LiteralPath (Join-Path $source '.env') -Destination $installedEnv
}
& (Join-Path $destination 'Setup-Windows.cmd')
if ($LASTEXITCODE -ne 0) { throw 'Dependency setup failed; review its error and rerun setup.' }
$shell = New-Object -ComObject WScript.Shell
$desktop = [Environment]::GetFolderPath('Desktop')
$link = $shell.CreateShortcut((Join-Path $desktop 'Jarvis AI Pro.lnk'))
$link.TargetPath = Join-Path $destination 'Run-Jarvis.cmd'
$link.WorkingDirectory = $destination
$link.Save()
Write-Host 'Installed. Launch Jarvis AI Pro from your desktop shortcut.'
