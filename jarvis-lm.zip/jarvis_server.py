"""Serve jarvis.html and proxy /v1 to LM Studio.

The browser blocks a file:// page from calling port 1234. This server
makes the page and the API the same origin.

  python jarvis_server.py
  open http://127.0.0.1:8787/jarvis.html

LM Studio still needs a loaded model and the local server on port 1234.
CORS can stay off.
"""

from http.server import ThreadingHTTPServer, SimpleHTTPRequestHandler
import os
import urllib.error
import urllib.request

LM = "http://127.0.0.1:1234"
PORT = 8787


class Handler(SimpleHTTPRequestHandler):
    def end_headers(self):
        self.send_header("Cache-Control", "no-store")
        super().end_headers()

    def do_GET(self):
        if self.path.startswith("/v1"):
            self.proxy()
            return
        super().do_GET()

    def do_POST(self):
        if self.path.startswith("/v1"):
            self.proxy()
            return
        self.send_error(404)

    def do_OPTIONS(self):
        self.send_response(204)
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Headers", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        self.end_headers()

    def proxy(self):
        length = int(self.headers.get("Content-Length", "0") or 0)
        body = self.rfile.read(length) if length else None
        req = urllib.request.Request(LM + self.path, data=body, method=self.command)
        if body:
            req.add_header("Content-Type", self.headers.get("Content-Type", "application/json"))
        req.add_header("Authorization", self.headers.get("Authorization", "Bearer lm-studio"))
        try:
            with urllib.request.urlopen(req, timeout=180) as resp:
                data = resp.read()
                self.send_response(resp.status)
                self.send_header("Content-Type", resp.headers.get("Content-Type", "application/json"))
                self.end_headers()
                self.wfile.write(data)
        except urllib.error.HTTPError as exc:
            data = exc.read()
            self.send_response(exc.code)
            self.send_header("Content-Type", "application/json")
            self.end_headers()
            self.wfile.write(data)
        except Exception as exc:
            message = ("LM Studio is not answering on port 1234. Load a model and start the local server. " + str(exc)).encode()
            self.send_response(502)
            self.send_header("Content-Type", "text/plain")
            self.end_headers()
            self.wfile.write(message)


if __name__ == "__main__":
    os.chdir(os.path.dirname(os.path.abspath(__file__)))
    print("Jarvis: http://127.0.0.1:%s/jarvis.html" % PORT)
    print("Proxying /v1 to %s" % LM)
    ThreadingHTTPServer(("127.0.0.1", PORT), Handler).serve_forever()
